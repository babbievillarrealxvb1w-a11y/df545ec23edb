// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Build genome index"); }
int main(){
  announce();
  return lionss_run_workload("genomeIndex");
}
