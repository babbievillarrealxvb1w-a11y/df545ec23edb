// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Profile hot methods"); }
int main(){
  announce();
  return lionss_run_workload("jitProfile");
}
