// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Match SIFT keypoints");
  std::fflush(stdout);
  return lionss_run_workload("sift-match");
}
