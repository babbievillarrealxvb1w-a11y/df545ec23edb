// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Train zstd dictionary\n", stdout);
  return lionss_run_workload("zstd-dict");
}
