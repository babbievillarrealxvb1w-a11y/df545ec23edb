// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Track snowy plover\n", stdout);
  return lionss_run_workload("SnowyPlover");
}
