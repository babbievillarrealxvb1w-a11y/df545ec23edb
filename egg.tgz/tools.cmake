# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(ColumnarEncode src/ColumnarEncode.cpp)
set_property(TARGET ColumnarEncode PROPERTY CXX_STANDARD 11)
target_link_libraries(ColumnarEncode lionss pthread)

add_executable(svdrandomized src/svdrandomized.cpp)
set_property(TARGET svdrandomized PROPERTY CXX_STANDARD 11)
target_link_libraries(svdrandomized lionss pthread)

add_executable(kingfisher-3 src/kingfisher-3.cpp)
set_property(TARGET kingfisher-3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kingfisher-3 lionss pthread)

add_executable(TcpCubic src/TcpCubic.cpp)
set_property(TARGET TcpCubic PROPERTY CXX_STANDARD 11)
target_link_libraries(TcpCubic lionss pthread)

add_executable(LbfgsTwoloop src/LbfgsTwoloop.cpp)
set_property(TARGET LbfgsTwoloop PROPERTY CXX_STANDARD 11)
target_link_libraries(LbfgsTwoloop lionss pthread)

add_executable(SnowyPlover src/SnowyPlover.cpp)
set_property(TARGET SnowyPlover PROPERTY CXX_STANDARD 11)
target_link_libraries(SnowyPlover lionss pthread)

add_executable(snippetCompile src/snippetCompile.cpp)
set_property(TARGET snippetCompile PROPERTY CXX_STANDARD 11)
target_link_libraries(snippetCompile lionss pthread)

add_executable(phyloraxml src/phyloraxml.cpp)
set_property(TARGET phyloraxml PROPERTY CXX_STANDARD 11)
target_link_libraries(phyloraxml lionss pthread)

add_executable(cosineWarmup src/cosineWarmup.cpp)
set_property(TARGET cosineWarmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cosineWarmup lionss pthread)

add_executable(windward src/windward.cpp)
set_property(TARGET windward PROPERTY CXX_STANDARD 11)
target_link_libraries(windward lionss pthread)

add_executable(marmot src/marmot.cpp)
set_property(TARGET marmot PROPERTY CXX_STANDARD 11)
target_link_libraries(marmot lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(helmLint src/helmLint.cpp)
set_property(TARGET helmLint PROPERTY CXX_STANDARD 11)
target_link_libraries(helmLint lionss pthread)

add_executable(IngestBronze src/IngestBronze.cpp)
set_property(TARGET IngestBronze PROPERTY CXX_STANDARD 11)
target_link_libraries(IngestBronze lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(fzf-preview src/fzf-preview.cpp)
set_property(TARGET fzf-preview PROPERTY CXX_STANDARD 11)
target_link_libraries(fzf-preview lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(hevc_tiles src/hevc_tiles.cpp)
set_property(TARGET hevc_tiles PROPERTY CXX_STANDARD 11)
target_link_libraries(hevc_tiles lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(genomeIndex src/genomeIndex.cpp)
set_property(TARGET genomeIndex PROPERTY CXX_STANDARD 11)
target_link_libraries(genomeIndex lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(occlusionPortal src/occlusionPortal.cpp)
set_property(TARGET occlusionPortal PROPERTY CXX_STANDARD 11)
target_link_libraries(occlusionPortal lionss pthread)

add_executable(jitProfile src/jitProfile.cpp)
set_property(TARGET jitProfile PROPERTY CXX_STANDARD 11)
target_link_libraries(jitProfile lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(stereoDepth src/stereoDepth.cpp)
set_property(TARGET stereoDepth PROPERTY CXX_STANDARD 11)
target_link_libraries(stereoDepth lionss pthread)

add_executable(osm-relation-fix src/osm-relation-fix.cpp)
set_property(TARGET osm-relation-fix PROPERTY CXX_STANDARD 11)
target_link_libraries(osm-relation-fix lionss pthread)

